import React from 'react'
import Sidebar from './Sidebar'
import Header from './Header'

function Upcomeing() {
  return (
    <div>
            <div style={{height:"100vh", width:"100%",display:"flex"}}>
        <div style={{width:"15%", height:"100vh", backgroundColor:"white",}}>
            <Sidebar/>
        </div>
        <div style={{width:"82%",marginLeft:"1.5%", height:"100vh", display:"flex", flexDirection:"column"}}>
            <Header/>
            <div style={{width:"100%", height:"73vh",backgroundColor:"white",alignItems:"center",display:"flex",gap:"2%"}}>
                <div style={{height:"70vh", width:"45%", backgroundColor:"white",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"space-evenly"}}>
                    <label>All students</label>
                    <div style={{height:"12vh", width:"95%", backgroundColor:"whitesmoke",borderRadius:"10px", display:"flex"}}>
                        <div style={{height:"12vh", width:"20%",display:"flex", justifyContent:"center", alignItems:"center"}}>
                            <div style={{height:"9vh", width:"70%",backgroundColor:"white",borderRadius:10,display:"flex", justifyContent:"center", alignItems:"center"}}>
                                <img style={{height:"5vh", width:"60%",}} src='https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/React-icon.svg/2300px-React-icon.svg.png'/>
                            </div>
                        </div>
                        <div style={{height:"12vh", width:"50%",display:"flex",flexDirection:"column",justifyContent:"center"}}>
                            <label style={{fontSize:"19px", fontWeight:"bold",letterSpacing:1,height:25}}>Krishna Joshi</label>
                            
                        </div>
                        <div style={{height:"12vh", width:"30%", display:"flex", justifyContent:"center",alignItems:"center"}}>
                            <button style={{height:"40px", width:"80%", backgroundColor:"black", color:"white",borderRadius:10,border:"none"}}>Veiw info</button>
                        </div>
                    </div>
                    <div style={{height:"12vh", width:"95%", backgroundColor:"whitesmoke",borderRadius:"10px", display:"flex"}}>
                        <div style={{height:"12vh", width:"20%",display:"flex", justifyContent:"center", alignItems:"center"}}>
                            <div style={{height:"9vh", width:"70%",backgroundColor:"white",borderRadius:10,display:"flex", justifyContent:"center", alignItems:"center"}}>
                                <img style={{height:"5vh", width:"60%",}} src='https://s3.dualstack.us-east-2.amazonaws.com/pythondotorg-assets/media/psf/trademarks-faq/python-logo-usa-outset-monochrome-BAD.png'/>
                            </div>
                        </div>
                        <div style={{height:"12vh", width:"50%",display:"flex",flexDirection:"column",justifyContent:"center"}}>
                            <label style={{fontSize:"19px", fontWeight:"bold",letterSpacing:1,height:25}}>Yash Malawant</label>
                        </div>
                        <div style={{height:"12vh", width:"30%", display:"flex", justifyContent:"center",alignItems:"center"}}>
                            <button style={{height:"40px", width:"80%", backgroundColor:"black", color:"white",borderRadius:10,border:"none"}}>Veiw info</button>
                        </div>
                    </div>
                    <div style={{height:"12vh", width:"95%", backgroundColor:"whitesmoke",borderRadius:"10px", display:"flex"}}>
                        <div style={{height:"12vh", width:"20%",display:"flex", justifyContent:"center", alignItems:"center"}}>
                            <div style={{height:"9vh", width:"70%",backgroundColor:"white",borderRadius:10,display:"flex", justifyContent:"center", alignItems:"center"}}>
                                <img style={{height:"5vh", width:"60%",}} src='https://cdn.pixabay.com/photo/2016/08/09/17/52/instagram-1581266_640.jpg'/>
                            </div>
                        </div>
                        <div style={{height:"12vh", width:"50%",display:"flex",flexDirection:"column",justifyContent:"center"}}>
                            <label style={{fontSize:"19px", fontWeight:"bold",letterSpacing:1,height:25}}>Yash Malawant</label>
                        </div>
                        <div style={{height:"12vh", width:"30%", display:"flex", justifyContent:"center",alignItems:"center"}}>
                            <button style={{height:"40px", width:"80%", backgroundColor:"black", color:"white",borderRadius:10,border:"none"}}>Veiw info</button>
                        </div>
                    </div>
                    <div style={{height:"12vh", width:"95%", backgroundColor:"whitesmoke",borderRadius:"10px", display:"flex"}}>
                        <div style={{height:"12vh", width:"20%",display:"flex", justifyContent:"center", alignItems:"center"}}>
                            <div style={{height:"9vh", width:"70%",backgroundColor:"white",borderRadius:10,display:"flex", justifyContent:"center", alignItems:"center"}}>
                                <img style={{height:"5vh", width:"60%",}} src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS5v-3wDKKkDFjrjEGs__MhuaOl5W1A8_46FxOdzH9wIQ&usqp=CAU&ec=48600113'/>
                            </div>
                        </div>
                        <div style={{height:"12vh", width:"50%",display:"flex",flexDirection:"column",justifyContent:"center"}}>
                            <label style={{fontSize:"19px", fontWeight:"bold",letterSpacing:1,height:25}}>Yash Malawant</label>
                        </div>
                        <div style={{height:"12vh", width:"30%", display:"flex", justifyContent:"center",alignItems:"center"}}>
                            <button style={{height:"40px", width:"80%", backgroundColor:"black", color:"white",borderRadius:10,border:"none"}}>Veiw info</button>
                        </div>
                    </div>
                    <div style={{height:"12vh", width:"95%", backgroundColor:"whitesmoke",borderRadius:"10px", display:"flex"}}>
                        <div style={{height:"12vh", width:"20%",display:"flex", justifyContent:"center", alignItems:"center"}}>
                            <div style={{height:"9vh", width:"70%",backgroundColor:"white",borderRadius:10,display:"flex", justifyContent:"center", alignItems:"center"}}>
                                <img style={{height:"5vh", width:"60%",}} src='https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTrXOeYrrq9ogVRZOXbVdkSlsG86GVYzDUlhSWeF4m4vQ&usqp=CAU&ec=48600113'/>
                            </div>
                        </div>
                        <div style={{height:"12vh", width:"50%",display:"flex",flexDirection:"column",justifyContent:"center"}}>
                            <label style={{fontSize:"19px", fontWeight:"bold",letterSpacing:1,height:25}}>Yash Malawant</label>
                        </div>
                        <div style={{height:"12vh", width:"30%", display:"flex", justifyContent:"center",alignItems:"center"}}>
                            <button style={{height:"40px", width:"80%", backgroundColor:"black", color:"white",borderRadius:10,border:"none"}}>Veiw info</button>
                        </div>
                    </div>
        
                </div>




                   <div style={{height:"70vh", width:"45%", backgroundColor:"white",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"space-evenly",}}>
                    <label>Up comeing classes</label>
                    <div style={{height:"12vh", width:"95%", backgroundColor:"whitesmoke",borderRadius:"10px", display:"flex"}}>
                        <div style={{height:"12vh", width:"70%",display:"flex", justifyContent:"center", alignItems:"center"}}>
                            <div style={{height:"9vh", width:"90%",backgroundColor:"white",borderRadius:10,display:"flex", justifyContent:"center", alignItems:"center"}}>
                               <label style={{fontWeight:"bold"}}>Python Virtual Class</label>
                            </div>
                        </div>
                    
                        <div style={{height:"12vh", width:"30%", display:"flex", justifyContent:"center",alignItems:"center",}}>
                            <button style={{height:"40px", width:"80%", backgroundColor:"black", color:"white",borderRadius:10,border:"none"}}>Sunday 9 am</button>
                        </div>
                    </div>
                    <div style={{height:"12vh", width:"95%", backgroundColor:"whitesmoke",borderRadius:"10px", display:"flex"}}>
                        <div style={{height:"12vh", width:"70%",display:"flex", justifyContent:"center", alignItems:"center"}}>
                            <div style={{height:"9vh", width:"90%",backgroundColor:"white",borderRadius:10,display:"flex", justifyContent:"center", alignItems:"center"}}>
                            <label style={{fontWeight:"bold"}}>Python Virtual Class</label>
                               
                            </div>
                        </div>
                    
                        <div style={{height:"12vh", width:"30%", display:"flex", justifyContent:"center",alignItems:"center",}}>
                            <button style={{height:"40px", width:"80%", backgroundColor:"black", color:"white",borderRadius:10,border:"none"}}>Monday 10 am</button>
                        </div>
                    </div>
                    <div style={{height:"12vh", width:"95%", backgroundColor:"whitesmoke",borderRadius:"10px", display:"flex"}}>
                        <div style={{height:"12vh", width:"70%",display:"flex", justifyContent:"center", alignItems:"center"}}>
                            <div style={{height:"9vh", width:"90%",backgroundColor:"white",borderRadius:10,display:"flex", justifyContent:"center", alignItems:"center"}}>
                            <label style={{fontWeight:"bold"}}>Python Virtual Class</label>
                               
                            </div>
                        </div>
                    
                        <div style={{height:"12vh", width:"30%", display:"flex", justifyContent:"center",alignItems:"center",}}>
                            <button style={{height:"40px", width:"80%", backgroundColor:"black", color:"white",borderRadius:10,border:"none"}}>Monday 2 pm</button>
                        </div>
                    </div>
                    <div style={{height:"12vh", width:"95%", backgroundColor:"whitesmoke",borderRadius:"10px", display:"flex"}}>
                        <div style={{height:"12vh", width:"70%",display:"flex", justifyContent:"center", alignItems:"center"}}>
                            <div style={{height:"9vh", width:"90%",backgroundColor:"white",borderRadius:10,display:"flex", justifyContent:"center", alignItems:"center"}}>
                            <label style={{fontWeight:"bold"}}>Python Virtual Class</label>
                               
                            </div>
                        </div>
                    
                        <div style={{height:"12vh", width:"30%", display:"flex", justifyContent:"center",alignItems:"center",}}>
                            <button style={{height:"40px", width:"80%", backgroundColor:"black", color:"white",borderRadius:10,border:"none"}}>Tueday 9 am</button>
                        </div>
                    </div>
                    <div style={{height:"12vh", width:"95%", backgroundColor:"white",borderRadius:"10px", display:"flex"}}>
                        
                    </div>
           
                   
        
                </div>
            </div>
        </div>
    </div>
    </div>
  )
}

export default Upcomeing